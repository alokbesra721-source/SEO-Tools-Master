import { LucideIcon, Search, Tag, Link, Copy, Award, Gauge, Smartphone, FileCode, Network, Link2, AlertCircle, Image, Scissors, Code, FileText, SearchCheck, Map, RefreshCw, AlignLeft, Shield } from "lucide-react";

export interface Tool {
  id: number;
  name: string;
  description: string;
  icon: LucideIcon;
  keywords: string[];
}

export const tools: Tool[] = [
  {
    id: 1,
    name: "Keyword Density Checker",
    description: "Analyze keyword density and frequency in your content to optimize SEO performance and avoid keyword stuffing.",
    icon: Search,
    keywords: ["keyword", "density", "seo", "content", "analysis"]
  },
  {
    id: 2,
    name: "Meta Tag Generator",
    description: "Generate SEO-optimized meta titles, descriptions, and keywords for better search engine visibility.",
    icon: Tag,
    keywords: ["meta", "tags", "title", "description", "seo"]
  },
  {
    id: 3,
    name: "Backlink Checker",
    description: "Check and analyze backlinks pointing to your website to improve your domain authority.",
    icon: Link,
    keywords: ["backlink", "links", "authority", "domain", "seo"]
  },
  {
    id: 4,
    name: "Plagiarism Checker",
    description: "Detect duplicate content and ensure your content is unique for better SEO rankings.",
    icon: Copy,
    keywords: ["plagiarism", "duplicate", "content", "unique", "check"]
  },
  {
    id: 5,
    name: "Domain Authority Checker",
    description: "Check your website's domain authority score and get insights to improve it.",
    icon: Award,
    keywords: ["domain", "authority", "da", "score", "rank"]
  },
  {
    id: 6,
    name: "Website Speed Test",
    description: "Test your website loading speed and get optimization recommendations for better performance.",
    icon: Gauge,
    keywords: ["speed", "performance", "load time", "optimization", "fast"]
  },
  {
    id: 7,
    name: "Mobile-Friendly Test",
    description: "Check if your website is mobile-friendly and responsive across different devices.",
    icon: Smartphone,
    keywords: ["mobile", "responsive", "device", "friendly", "test"]
  },
  {
    id: 8,
    name: "Robots.txt Generator",
    description: "Create a properly formatted robots.txt file to control search engine crawlers.",
    icon: FileCode,
    keywords: ["robots", "txt", "crawler", "seo", "generator"]
  },
  {
    id: 9,
    name: "Sitemap Generator",
    description: "Generate XML sitemaps for your website to improve search engine indexing.",
    icon: Network,
    keywords: ["sitemap", "xml", "generator", "index", "seo"]
  },
  {
    id: 10,
    name: "URL Shortener",
    description: "Create short, branded URLs for better sharing and tracking on social media.",
    icon: Link2,
    keywords: ["url", "shortener", "link", "short", "share"]
  },
  {
    id: 11,
    name: "Broken Link Checker",
    description: "Find and fix broken links on your website to improve user experience and SEO.",
    icon: AlertCircle,
    keywords: ["broken", "link", "404", "checker", "fix"]
  },
  {
    id: 12,
    name: "Image Compressor",
    description: "Compress images without losing quality to improve website loading speed.",
    icon: Image,
    keywords: ["image", "compress", "optimize", "size", "reduce"]
  },
  {
    id: 13,
    name: "CSS Minifier",
    description: "Minify CSS files to reduce file size and improve website performance.",
    icon: Scissors,
    keywords: ["css", "minify", "compress", "optimize", "code"]
  },
  {
    id: 14,
    name: "JS Minifier",
    description: "Minify JavaScript files to reduce load times and boost page speed.",
    icon: Code,
    keywords: ["javascript", "js", "minify", "compress", "optimize"]
  },
  {
    id: 15,
    name: "HTML Formatter",
    description: "Format and beautify HTML code for better readability and maintenance.",
    icon: FileText,
    keywords: ["html", "formatter", "beautify", "code", "format"]
  },
  {
    id: 16,
    name: "SEO Audit Tool",
    description: "Perform comprehensive SEO audit of your website and get actionable recommendations.",
    icon: SearchCheck,
    keywords: ["seo", "audit", "analysis", "check", "report"]
  },
  {
    id: 17,
    name: "XML Sitemap Validator",
    description: "Validate your XML sitemap for errors and ensure proper search engine submission.",
    icon: Map,
    keywords: ["xml", "sitemap", "validator", "check", "validate"]
  },
  {
    id: 18,
    name: "Redirect Checker",
    description: "Check redirect chains and ensure proper 301/302 redirects for SEO.",
    icon: RefreshCw,
    keywords: ["redirect", "301", "302", "checker", "url"]
  },
  {
    id: 19,
    name: "Meta Description Analyzer",
    description: "Analyze and optimize your meta descriptions for maximum click-through rates.",
    icon: AlignLeft,
    keywords: ["meta", "description", "analyzer", "ctr", "optimize"]
  },
  {
    id: 20,
    name: "SSL Checker",
    description: "Verify SSL certificate installation and security status of your website.",
    icon: Shield,
    keywords: ["ssl", "https", "security", "certificate", "check"]
  }
];
