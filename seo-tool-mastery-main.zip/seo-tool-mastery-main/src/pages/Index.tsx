import { useState } from "react";
import { Hero } from "@/components/Hero";
import { ToolCard } from "@/components/ToolCard";
import { ToolModal } from "@/components/ToolModal";
import { FAQ } from "@/components/FAQ";
import { About } from "@/components/About";
import { Blog } from "@/components/Blog";
import { Footer } from "@/components/Footer";
import { ThemeToggle } from "@/components/ThemeToggle";
import { tools, Tool } from "@/data/tools";

const Index = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedTool, setSelectedTool] = useState<Tool | null>(null);
  const [modalOpen, setModalOpen] = useState(false);

  const filteredTools = tools.filter(tool => 
    tool.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    tool.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
    tool.keywords.some(keyword => keyword.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const handleOpenTool = (tool: Tool) => {
    setSelectedTool(tool);
    setModalOpen(true);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Schema.org JSON-LD */}
      <script type="application/ld+json">
        {JSON.stringify({
          "@context": "https://schema.org",
          "@type": "WebApplication",
          "name": "SEO Tools Master",
          "description": "20 Free SEO Tools to Boost Your Website Rankings",
          "url": "https://seotoolsmaster.com",
          "applicationCategory": "BusinessApplication",
          "offers": {
            "@type": "Offer",
            "price": "0",
            "priceCurrency": "USD"
          }
        })}
      </script>

      {/* Header */}
      <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            SEO Tools Master
          </h1>
          <ThemeToggle />
        </div>
      </header>

      {/* Hero Section */}
      <Hero onSearch={setSearchQuery} />

      {/* Tools Grid */}
      <main className="container mx-auto px-4 py-16">
        <section id="tools">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Our SEO Tools Collection</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              {filteredTools.length === tools.length 
                ? "Explore all 20 powerful SEO tools designed to boost your website's performance"
                : `Found ${filteredTools.length} tool${filteredTools.length !== 1 ? 's' : ''} matching "${searchQuery}"`
              }
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredTools.map((tool) => (
              <ToolCard key={tool.id} tool={tool} onOpenTool={handleOpenTool} />
            ))}
          </div>

          {filteredTools.length === 0 && (
            <div className="text-center py-12">
              <p className="text-lg text-muted-foreground">
                No tools found matching "{searchQuery}". Try a different search term.
              </p>
            </div>
          )}
        </section>
      </main>

      {/* About Section */}
      <About />

      {/* Blog Section */}
      <Blog />

      {/* FAQ Section */}
      <FAQ />

      {/* Footer */}
      <Footer />

      {/* Tool Modal */}
      <ToolModal tool={selectedTool} open={modalOpen} onOpenChange={setModalOpen} />
    </div>
  );
};

export default Index;
