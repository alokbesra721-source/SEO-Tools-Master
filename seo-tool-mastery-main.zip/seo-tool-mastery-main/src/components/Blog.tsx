import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { BookOpen, TrendingUp, Zap } from "lucide-react";

const articles = [
  {
    title: "10 Essential SEO Tools Every Digital Marketer Needs in 2025",
    description: "Discover the must-have free SEO tools that can skyrocket your website rankings and drive organic traffic. From keyword research to technical audits, we cover everything you need.",
    icon: TrendingUp,
    readTime: "5 min read",
    category: "SEO Strategy"
  },
  {
    title: "How to Optimize Meta Tags for Maximum Click-Through Rates",
    description: "Learn the proven techniques to craft compelling meta titles and descriptions that improve your CTR by up to 35%. Includes real examples and best practices.",
    icon: Zap,
    readTime: "7 min read",
    category: "On-Page SEO"
  },
  {
    title: "Complete Guide to Website Speed Optimization",
    description: "Page speed is a critical ranking factor. This comprehensive guide shows you how to reduce load times, improve Core Web Vitals, and boost your Google rankings.",
    icon: BookOpen,
    readTime: "10 min read",
    category: "Technical SEO"
  }
];

export function Blog() {
  return (
    <section className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12 animate-fade-in">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            SEO Insights & Best Practices
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Expert guides and actionable tips to improve your search engine rankings
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {articles.map((article, index) => {
            const Icon = article.icon;
            return (
              <Card 
                key={index} 
                className="hover:shadow-lg transition-all duration-300 hover:-translate-y-1 cursor-pointer"
              >
                <CardHeader>
                  <div className="flex items-center gap-3 mb-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-primary to-accent text-white">
                      <Icon className="h-5 w-5" />
                    </div>
                    <span className="text-xs font-medium text-primary">{article.category}</span>
                  </div>
                  <CardTitle className="text-xl leading-tight">{article.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="mb-4 text-base">
                    {article.description}
                  </CardDescription>
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <span>{article.readTime}</span>
                    <span className="text-primary font-medium hover:underline">Read more →</span>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <div className="mt-12 max-w-4xl mx-auto">
          <Card className="bg-gradient-to-br from-primary/5 to-accent/5">
            <CardContent className="pt-6">
              <h3 className="text-2xl font-bold mb-4">Why SEO Tools Matter for Your Business</h3>
              <div className="space-y-3 text-muted-foreground">
                <p>
                  Search Engine Optimization has become the cornerstone of digital marketing success. With over 93% of online experiences beginning with a search engine, having the right SEO tools can mean the difference between being found or being invisible.
                </p>
                <p>
                  Our comprehensive suite of 20 free SEO tools empowers businesses of all sizes to compete effectively in search rankings. From analyzing keyword density to checking website speed, each tool is designed to address specific aspects of SEO that directly impact your visibility.
                </p>
                <p>
                  Whether you're optimizing meta tags, compressing images for faster load times, or auditing your entire website, these tools provide actionable insights that help you make data-driven decisions. The best part? They're completely free and available 24/7.
                </p>
                <p className="font-semibold text-foreground pt-2">
                  Start using our tools today and watch your search engine rankings soar. Every tool is built with user experience in mind, requiring no technical expertise while delivering professional-grade results.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
