import { Tool } from "@/data/tools";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { KeywordDensityChecker } from "./tools/KeywordDensityChecker";
import { MetaTagGenerator } from "./tools/MetaTagGenerator";
import { ImageCompressor } from "./tools/ImageCompressor";
import { CSSMinifier } from "./tools/CSSMinifier";
import { RobotsTxtGenerator } from "./tools/RobotsTxtGenerator";
import { BacklinkChecker } from "./tools/BacklinkChecker";
import { PlagiarismChecker } from "./tools/PlagiarismChecker";
import { DomainAuthorityChecker } from "./tools/DomainAuthorityChecker";
import { WebsiteSpeedTest } from "./tools/WebsiteSpeedTest";
import { MobileFriendlyTest } from "./tools/MobileFriendlyTest";
import { SitemapGenerator } from "./tools/SitemapGenerator";
import { URLShortener } from "./tools/URLShortener";
import { BrokenLinkChecker } from "./tools/BrokenLinkChecker";
import { JSMinifier } from "./tools/JSMinifier";
import { HTMLFormatter } from "./tools/HTMLFormatter";
import { SEOAuditTool } from "./tools/SEOAuditTool";
import { XMLSitemapValidator } from "./tools/XMLSitemapValidator";
import { RedirectChecker } from "./tools/RedirectChecker";
import { MetaDescriptionAnalyzer } from "./tools/MetaDescriptionAnalyzer";
import { SSLChecker } from "./tools/SSLChecker";
import { GenericTool } from "./tools/GenericTool";

interface ToolModalProps {
  tool: Tool | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function ToolModal({ tool, open, onOpenChange }: ToolModalProps) {
  if (!tool) return null;

  const renderToolContent = () => {
    switch (tool.id) {
      case 1:
        return <KeywordDensityChecker />;
      case 2:
        return <MetaTagGenerator />;
      case 3:
        return <BacklinkChecker />;
      case 4:
        return <PlagiarismChecker />;
      case 5:
        return <DomainAuthorityChecker />;
      case 6:
        return <WebsiteSpeedTest />;
      case 7:
        return <MobileFriendlyTest />;
      case 8:
        return <RobotsTxtGenerator />;
      case 9:
        return <SitemapGenerator />;
      case 10:
        return <URLShortener />;
      case 11:
        return <BrokenLinkChecker />;
      case 12:
        return <ImageCompressor />;
      case 13:
        return <CSSMinifier />;
      case 14:
        return <JSMinifier />;
      case 15:
        return <HTMLFormatter />;
      case 16:
        return <SEOAuditTool />;
      case 17:
        return <XMLSitemapValidator />;
      case 18:
        return <RedirectChecker />;
      case 19:
        return <MetaDescriptionAnalyzer />;
      case 20:
        return <SSLChecker />;
      default:
        return <GenericTool tool={tool} />;
    }
  };

  const Icon = tool.icon;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center gap-3 mb-2">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-primary to-accent text-white">
              <Icon className="h-5 w-5" />
            </div>
            <DialogTitle className="text-2xl">{tool.name}</DialogTitle>
          </div>
          <DialogDescription className="text-base">{tool.description}</DialogDescription>
        </DialogHeader>
        <div className="mt-4">{renderToolContent()}</div>
      </DialogContent>
    </Dialog>
  );
}
