import { Tool } from "@/data/tools";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";

interface ToolCardProps {
  tool: Tool;
  onOpenTool: (tool: Tool) => void;
}

export function ToolCard({ tool, onOpenTool }: ToolCardProps) {
  const Icon = tool.icon;
  
  return (
    <Card className="group transition-all duration-300 hover:shadow-lg hover:-translate-y-1">
      <CardHeader>
        <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-lg bg-gradient-to-br from-primary to-accent text-white shadow-md transition-transform group-hover:scale-110">
          <Icon className="h-6 w-6" />
        </div>
        <CardTitle className="text-xl">{tool.name}</CardTitle>
      </CardHeader>
      <CardContent>
        <CardDescription className="text-base">{tool.description}</CardDescription>
      </CardContent>
      <CardFooter>
        <Button 
          onClick={() => onOpenTool(tool)}
          className="w-full bg-gradient-to-r from-primary to-accent hover:opacity-90"
        >
          Open Tool
        </Button>
      </CardFooter>
    </Card>
  );
}
