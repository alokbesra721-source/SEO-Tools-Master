import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

export function FAQ() {
  const faqs = [
    {
      question: "Are all SEO tools completely free?",
      answer: "Yes, all 20 SEO tools on SEO Tools Master are completely free to use. No registration or payment required."
    },
    {
      question: "Do I need to create an account to use the tools?",
      answer: "No account creation is needed. All tools are accessible immediately without any registration."
    },
    {
      question: "How accurate are the SEO analysis results?",
      answer: "Our tools use industry-standard algorithms and best practices to provide accurate SEO analysis and recommendations."
    },
    {
      question: "Can I use these tools for multiple websites?",
      answer: "Absolutely! You can analyze as many websites as you need with any of our tools."
    },
    {
      question: "Are the tools mobile-friendly?",
      answer: "Yes, all our tools are fully responsive and work perfectly on mobile devices, tablets, and desktops."
    },
    {
      question: "How often are the tools updated?",
      answer: "We regularly update our tools to align with the latest SEO best practices and search engine algorithm changes."
    }
  ];

  return (
    <section id="faq" className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Frequently Asked Questions</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Find answers to common questions about our SEO tools
          </p>
        </div>
        
        <div className="max-w-3xl mx-auto">
          <Accordion type="single" collapsible className="w-full">
            {faqs.map((faq, index) => (
              <AccordionItem key={index} value={`item-${index}`}>
                <AccordionTrigger className="text-left text-lg">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-base text-muted-foreground">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  );
}
