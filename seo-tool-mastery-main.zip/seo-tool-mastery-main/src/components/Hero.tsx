import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";

interface HeroProps {
  onSearch: (query: string) => void;
}

export function Hero({ onSearch }: HeroProps) {
  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-primary/10 via-accent/5 to-background py-20 md:py-32">
      <div className="container mx-auto px-4">
        <div className="flex flex-col items-center text-center">
          <div className="mb-6 animate-float">
            <div className="flex h-20 w-20 items-center justify-center rounded-2xl bg-gradient-to-br from-primary to-accent shadow-lg">
              <Search className="h-10 w-10 text-white" />
            </div>
          </div>
          
          <h1 className="mb-4 text-4xl font-bold tracking-tight md:text-6xl lg:text-7xl">
            SEO Tools Master
          </h1>
          
          <p className="mb-8 max-w-2xl text-lg text-muted-foreground md:text-xl">
            Boost Your Website Rankings with 20 Powerful SEO Tools — All in One Place!
          </p>
          
          <div className="w-full max-w-2xl">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search tools... (e.g., keyword, meta tags, backlinks)"
                className="h-14 pl-12 text-lg shadow-lg"
                onChange={(e) => onSearch(e.target.value)}
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
