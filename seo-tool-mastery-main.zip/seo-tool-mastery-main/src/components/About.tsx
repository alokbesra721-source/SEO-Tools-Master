export function About() {
  return (
    <section id="about" className="py-20">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold mb-6 text-center">About SEO Tools Master</h2>
          
          <div className="space-y-6 text-lg text-muted-foreground">
            <p>
              SEO Tools Master is your comprehensive, free platform for all essential SEO tools. 
              We've gathered the 20 most searched and valuable SEO tools in one convenient location, 
              making it easier than ever to optimize your website for search engines.
            </p>
            
            <p>
              Whether you're a beginner blogger, a professional SEO specialist, or a business owner 
              looking to improve your online presence, our tools provide instant insights and actionable 
              recommendations to boost your website's rankings.
            </p>
            
            <div className="grid md:grid-cols-3 gap-6 my-8">
              <div className="text-center p-6 rounded-lg bg-muted/50">
                <div className="text-4xl font-bold text-primary mb-2">20+</div>
                <div className="text-sm">SEO Tools</div>
              </div>
              <div className="text-center p-6 rounded-lg bg-muted/50">
                <div className="text-4xl font-bold text-primary mb-2">100%</div>
                <div className="text-sm">Free Forever</div>
              </div>
              <div className="text-center p-6 rounded-lg bg-muted/50">
                <div className="text-4xl font-bold text-primary mb-2">24/7</div>
                <div className="text-sm">Available</div>
              </div>
            </div>
            
            <p>
              Our mission is to democratize SEO by providing professional-grade tools without the 
              hefty price tag. We believe every website deserves a chance to rank well in search 
              engines, regardless of budget constraints.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
