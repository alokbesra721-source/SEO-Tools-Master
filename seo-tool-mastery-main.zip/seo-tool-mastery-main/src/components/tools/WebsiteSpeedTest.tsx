import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";

export function WebsiteSpeedTest() {
  const [url, setUrl] = useState("");
  const [results, setResults] = useState<{
    loadTime: number;
    pageSize: number;
    requests: number;
    performance: number;
    suggestions: string[];
  } | null>(null);
  const [loading, setLoading] = useState(false);

  const testSpeed = () => {
    if (!url.trim()) {
      toast.error("Please enter a URL");
      return;
    }

    setLoading(true);
    
    // Simulate speed test
    setTimeout(() => {
      const loadTime = (Math.random() * 3 + 0.5).toFixed(2);
      const pageSize = (Math.random() * 3 + 1).toFixed(2);
      const requests = Math.floor(Math.random() * 50) + 20;
      const performance = Math.floor(Math.random() * 30) + 70;
      
      const suggestions = [
        "Enable compression to reduce response size",
        "Leverage browser caching",
        "Minify CSS and JavaScript files",
        "Optimize images for faster loading",
        "Reduce server response time"
      ].sort(() => Math.random() - 0.5).slice(0, 3);
      
      setResults({ loadTime: parseFloat(loadTime), pageSize: parseFloat(pageSize), requests, performance, suggestions });
      setLoading(false);
      toast.success("Speed test completed!");
    }, 2000);
  };

  return (
    <div className="space-y-4">
      <div>
        <Label htmlFor="url">Website URL</Label>
        <Input
          id="url"
          placeholder="https://yourwebsite.com"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
        />
      </div>

      <Button onClick={testSpeed} className="w-full" disabled={loading}>
        {loading ? "Testing Speed..." : "Test Website Speed"}
      </Button>

      {results && (
        <Card>
          <CardHeader>
            <CardTitle>Speed Test Results</CardTitle>
            <CardDescription>{url}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-center p-6 border rounded-lg bg-muted/50">
              <div className={`text-5xl font-bold ${
                results.performance >= 90 ? 'text-green-500' :
                results.performance >= 70 ? 'text-yellow-500' : 'text-red-500'
              }`}>
                {results.performance}
              </div>
              <div className="text-sm text-muted-foreground mt-2">Performance Score</div>
            </div>
            
            <div className="grid grid-cols-3 gap-4">
              <div className="text-center p-3 border rounded">
                <div className="text-2xl font-bold text-primary">{results.loadTime}s</div>
                <div className="text-xs text-muted-foreground mt-1">Load Time</div>
              </div>
              
              <div className="text-center p-3 border rounded">
                <div className="text-2xl font-bold text-primary">{results.pageSize}MB</div>
                <div className="text-xs text-muted-foreground mt-1">Page Size</div>
              </div>
              
              <div className="text-center p-3 border rounded">
                <div className="text-2xl font-bold text-primary">{results.requests}</div>
                <div className="text-xs text-muted-foreground mt-1">Requests</div>
              </div>
            </div>

            <div>
              <h4 className="font-semibold text-sm mb-2">Optimization Suggestions:</h4>
              <ul className="space-y-1">
                {results.suggestions.map((suggestion, index) => (
                  <li key={index} className="text-sm text-muted-foreground flex items-start gap-2">
                    <span className="text-primary">•</span>
                    {suggestion}
                  </li>
                ))}
              </ul>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
