import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";

export function DomainAuthorityChecker() {
  const [url, setUrl] = useState("");
  const [metrics, setMetrics] = useState<{
    da: number;
    pa: number;
    spam: number;
    backlinks: number;
    domains: number;
  } | null>(null);
  const [loading, setLoading] = useState(false);

  const checkAuthority = () => {
    if (!url.trim()) {
      toast.error("Please enter a domain");
      return;
    }

    setLoading(true);
    
    // Simulate DA checking
    setTimeout(() => {
      const da = Math.floor(Math.random() * 40) + 40; // 40-80
      const pa = Math.floor(Math.random() * 40) + 40; // 40-80
      const spam = Math.floor(Math.random() * 15); // 0-15
      const backlinks = Math.floor(Math.random() * 50000) + 5000;
      const domains = Math.floor(Math.random() * 2000) + 500;
      
      setMetrics({ da, pa, spam, backlinks, domains });
      setLoading(false);
      toast.success("Domain authority analyzed!");
    }, 1500);
  };

  const getScoreColor = (score: number) => {
    if (score >= 70) return "text-green-500";
    if (score >= 50) return "text-yellow-500";
    return "text-red-500";
  };

  return (
    <div className="space-y-4">
      <div>
        <Label htmlFor="domain">Domain URL</Label>
        <Input
          id="domain"
          placeholder="example.com"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
        />
      </div>

      <Button onClick={checkAuthority} className="w-full" disabled={loading}>
        {loading ? "Analyzing..." : "Check Domain Authority"}
      </Button>

      {metrics && (
        <Card>
          <CardHeader>
            <CardTitle>Domain Metrics</CardTitle>
            <CardDescription>{url}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-4 border rounded-lg">
                <div className={`text-3xl font-bold ${getScoreColor(metrics.da)}`}>
                  {metrics.da}
                </div>
                <div className="text-sm text-muted-foreground mt-1">Domain Authority</div>
              </div>
              
              <div className="text-center p-4 border rounded-lg">
                <div className={`text-3xl font-bold ${getScoreColor(metrics.pa)}`}>
                  {metrics.pa}
                </div>
                <div className="text-sm text-muted-foreground mt-1">Page Authority</div>
              </div>
              
              <div className="text-center p-4 border rounded-lg">
                <div className={`text-3xl font-bold ${metrics.spam < 5 ? 'text-green-500' : metrics.spam < 10 ? 'text-yellow-500' : 'text-red-500'}`}>
                  {metrics.spam}%
                </div>
                <div className="text-sm text-muted-foreground mt-1">Spam Score</div>
              </div>
              
              <div className="text-center p-4 border rounded-lg">
                <div className="text-3xl font-bold text-primary">
                  {metrics.backlinks.toLocaleString()}
                </div>
                <div className="text-sm text-muted-foreground mt-1">Total Backlinks</div>
              </div>
              
              <div className="col-span-2 text-center p-4 border rounded-lg">
                <div className="text-3xl font-bold text-primary">
                  {metrics.domains.toLocaleString()}
                </div>
                <div className="text-sm text-muted-foreground mt-1">Referring Domains</div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
