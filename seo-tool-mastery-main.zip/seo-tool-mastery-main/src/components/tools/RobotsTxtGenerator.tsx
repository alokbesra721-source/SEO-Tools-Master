import { useState } from "react";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";

export function RobotsTxtGenerator() {
  const [allowAll, setAllowAll] = useState(true);
  const [sitemap, setSitemap] = useState("");
  const [generated, setGenerated] = useState("");

  const generateRobotsTxt = () => {
    let robotsTxt = "User-agent: *\n";
    robotsTxt += allowAll ? "Allow: /\n" : "Disallow: /\n";
    
    if (sitemap.trim()) {
      robotsTxt += `\nSitemap: ${sitemap}`;
    }

    setGenerated(robotsTxt);
    toast.success("robots.txt generated successfully!");
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(generated);
    toast.success("Copied to clipboard!");
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center space-x-2">
        <Checkbox
          id="allowAll"
          checked={allowAll}
          onCheckedChange={(checked) => setAllowAll(checked as boolean)}
        />
        <Label htmlFor="allowAll" className="cursor-pointer">
          Allow all robots to crawl your site
        </Label>
      </div>

      <div>
        <Label htmlFor="sitemap">Sitemap URL (optional)</Label>
        <Input
          id="sitemap"
          placeholder="https://yoursite.com/sitemap.xml"
          value={sitemap}
          onChange={(e) => setSitemap(e.target.value)}
        />
      </div>

      <Button onClick={generateRobotsTxt} className="w-full">
        Generate robots.txt
      </Button>

      {generated && (
        <div>
          <div className="flex justify-between items-center mb-2">
            <Label>Generated robots.txt</Label>
            <Button variant="outline" size="sm" onClick={copyToClipboard}>
              Copy
            </Button>
          </div>
          <Textarea
            value={generated}
            readOnly
            className="min-h-[150px] font-mono text-sm bg-muted"
          />
        </div>
      )}
    </div>
  );
}
