import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

export function MetaTagGenerator() {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [keywords, setKeywords] = useState("");
  const [author, setAuthor] = useState("");

  const generateMetaTags = () => {
    const metaTags = `<!-- Meta Tags -->
<title>${title}</title>
<meta name="description" content="${description}">
<meta name="keywords" content="${keywords}">
<meta name="author" content="${author}">

<!-- Open Graph Tags -->
<meta property="og:title" content="${title}">
<meta property="og:description" content="${description}">
<meta property="og:type" content="website">

<!-- Twitter Card Tags -->
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="${title}">
<meta name="twitter:description" content="${description}">`;

    navigator.clipboard.writeText(metaTags);
    toast.success("Meta tags copied to clipboard!");
  };

  return (
    <div className="space-y-4">
      <div>
        <Label htmlFor="title">Page Title</Label>
        <Input
          id="title"
          placeholder="Your page title (max 60 characters)"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          maxLength={60}
        />
        <p className="text-xs text-muted-foreground mt-1">{title.length}/60 characters</p>
      </div>

      <div>
        <Label htmlFor="description">Meta Description</Label>
        <Textarea
          id="description"
          placeholder="Your meta description (max 160 characters)"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          maxLength={160}
        />
        <p className="text-xs text-muted-foreground mt-1">{description.length}/160 characters</p>
      </div>

      <div>
        <Label htmlFor="keywords">Keywords</Label>
        <Input
          id="keywords"
          placeholder="keyword1, keyword2, keyword3"
          value={keywords}
          onChange={(e) => setKeywords(e.target.value)}
        />
      </div>

      <div>
        <Label htmlFor="author">Author</Label>
        <Input
          id="author"
          placeholder="Your name or company"
          value={author}
          onChange={(e) => setAuthor(e.target.value)}
        />
      </div>

      <Button onClick={generateMetaTags} className="w-full">
        Generate & Copy Meta Tags
      </Button>
    </div>
  );
}
