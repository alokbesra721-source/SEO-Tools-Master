import { useState } from "react";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";
import { AlertCircle, CheckCircle } from "lucide-react";

export function PlagiarismChecker() {
  const [text, setText] = useState("");
  const [result, setResult] = useState<{ uniqueness: number; matches: string[] } | null>(null);
  const [loading, setLoading] = useState(false);

  const checkPlagiarism = () => {
    if (!text.trim()) {
      toast.error("Please enter text to check");
      return;
    }

    setLoading(true);
    
    // Simulate plagiarism checking
    setTimeout(() => {
      const uniqueness = Math.floor(Math.random() * 30) + 70; // 70-100%
      const matches = uniqueness < 95 ? [
        "https://example.com/similar-content",
        "https://wikipedia.org/related-topic"
      ] : [];
      
      setResult({ uniqueness, matches });
      setLoading(false);
      
      if (uniqueness >= 95) {
        toast.success("Content is unique!");
      } else {
        toast.warning("Some similarities found");
      }
    }, 2000);
  };

  return (
    <div className="space-y-4">
      <div>
        <Label htmlFor="text">Paste Your Content</Label>
        <Textarea
          id="text"
          placeholder="Enter or paste your text here to check for plagiarism..."
          value={text}
          onChange={(e) => setText(e.target.value)}
          className="min-h-[200px]"
        />
        <p className="text-xs text-muted-foreground mt-1">
          {text.split(/\s+/).filter(w => w.length > 0).length} words
        </p>
      </div>

      <Button onClick={checkPlagiarism} className="w-full" disabled={loading}>
        {loading ? "Scanning..." : "Check Plagiarism"}
      </Button>

      {result && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              {result.uniqueness >= 95 ? (
                <CheckCircle className="h-5 w-5 text-green-500" />
              ) : (
                <AlertCircle className="h-5 w-5 text-yellow-500" />
              )}
              Uniqueness Score: {result.uniqueness}%
            </CardTitle>
            <CardDescription>
              {result.uniqueness >= 95 
                ? "Your content appears to be original" 
                : "Some similarities detected"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="w-full bg-muted rounded-full h-3">
                <div 
                  className={`h-3 rounded-full transition-all ${
                    result.uniqueness >= 95 ? 'bg-green-500' : 
                    result.uniqueness >= 80 ? 'bg-yellow-500' : 'bg-red-500'
                  }`}
                  style={{ width: `${result.uniqueness}%` }}
                />
              </div>
              
              {result.matches.length > 0 && (
                <div className="mt-4">
                  <h4 className="font-medium text-sm mb-2">Similar Content Found:</h4>
                  {result.matches.map((match, index) => (
                    <a 
                      key={index}
                      href={match}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="block text-xs text-primary hover:underline mb-1"
                    >
                      {match}
                    </a>
                  ))}
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
