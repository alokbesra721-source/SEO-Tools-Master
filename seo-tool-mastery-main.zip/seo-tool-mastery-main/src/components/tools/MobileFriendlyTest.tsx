import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";
import { CheckCircle, XCircle } from "lucide-react";

export function MobileFriendlyTest() {
  const [url, setUrl] = useState("");
  const [results, setResults] = useState<{
    isMobileFriendly: boolean;
    viewport: boolean;
    textSize: boolean;
    tapTargets: boolean;
    contentWidth: boolean;
    issues: string[];
  } | null>(null);
  const [loading, setLoading] = useState(false);

  const testMobile = () => {
    if (!url.trim()) {
      toast.error("Please enter a URL");
      return;
    }

    setLoading(true);
    
    // Simulate mobile-friendly test
    setTimeout(() => {
      const isMobileFriendly = Math.random() > 0.3;
      const viewport = Math.random() > 0.2;
      const textSize = Math.random() > 0.3;
      const tapTargets = Math.random() > 0.4;
      const contentWidth = Math.random() > 0.2;
      
      const allIssues = [
        "Text too small to read",
        "Links too close together",
        "Content wider than screen",
        "Viewport not set"
      ];
      
      const issues: string[] = [];
      if (!viewport) issues.push(allIssues[3]);
      if (!textSize) issues.push(allIssues[0]);
      if (!tapTargets) issues.push(allIssues[1]);
      if (!contentWidth) issues.push(allIssues[2]);
      
      setResults({ isMobileFriendly, viewport, textSize, tapTargets, contentWidth, issues });
      setLoading(false);
      
      if (isMobileFriendly) {
        toast.success("Page is mobile-friendly!");
      } else {
        toast.warning("Mobile issues detected");
      }
    }, 1500);
  };

  return (
    <div className="space-y-4">
      <div>
        <Label htmlFor="url">Website URL</Label>
        <Input
          id="url"
          placeholder="https://yourwebsite.com"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
        />
      </div>

      <Button onClick={testMobile} className="w-full" disabled={loading}>
        {loading ? "Testing..." : "Test Mobile-Friendliness"}
      </Button>

      {results && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              {results.isMobileFriendly ? (
                <>
                  <CheckCircle className="h-5 w-5 text-green-500" />
                  Mobile-Friendly
                </>
              ) : (
                <>
                  <XCircle className="h-5 w-5 text-red-500" />
                  Not Mobile-Friendly
                </>
              )}
            </CardTitle>
            <CardDescription>{url}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between p-2 border rounded">
                <span className="text-sm">Viewport configured</span>
                {results.viewport ? (
                  <CheckCircle className="h-4 w-4 text-green-500" />
                ) : (
                  <XCircle className="h-4 w-4 text-red-500" />
                )}
              </div>
              
              <div className="flex items-center justify-between p-2 border rounded">
                <span className="text-sm">Text is readable</span>
                {results.textSize ? (
                  <CheckCircle className="h-4 w-4 text-green-500" />
                ) : (
                  <XCircle className="h-4 w-4 text-red-500" />
                )}
              </div>
              
              <div className="flex items-center justify-between p-2 border rounded">
                <span className="text-sm">Tap targets sized appropriately</span>
                {results.tapTargets ? (
                  <CheckCircle className="h-4 w-4 text-green-500" />
                ) : (
                  <XCircle className="h-4 w-4 text-red-500" />
                )}
              </div>
              
              <div className="flex items-center justify-between p-2 border rounded">
                <span className="text-sm">Content fits screen width</span>
                {results.contentWidth ? (
                  <CheckCircle className="h-4 w-4 text-green-500" />
                ) : (
                  <XCircle className="h-4 w-4 text-red-500" />
                )}
              </div>
            </div>

            {results.issues.length > 0 && (
              <div className="bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-900 rounded-lg p-3">
                <h4 className="font-semibold text-sm text-red-900 dark:text-red-200 mb-2">Issues Found:</h4>
                <ul className="space-y-1">
                  {results.issues.map((issue, index) => (
                    <li key={index} className="text-sm text-red-800 dark:text-red-300">• {issue}</li>
                  ))}
                </ul>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
