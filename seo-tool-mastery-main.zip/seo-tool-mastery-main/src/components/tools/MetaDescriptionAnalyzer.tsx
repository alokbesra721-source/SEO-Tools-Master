import { useState } from "react";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckCircle, XCircle, AlertCircle } from "lucide-react";

export function MetaDescriptionAnalyzer() {
  const [description, setDescription] = useState("");
  const [analysis, setAnalysis] = useState<{
    length: number;
    isOptimal: boolean;
    hasKeyword: boolean;
    hasCallToAction: boolean;
    score: number;
    suggestions: string[];
  } | null>(null);

  const analyzeDescription = () => {
    const length = description.length;
    const isOptimal = length >= 120 && length <= 160;
    
    // Simple keyword detection (looking for common SEO terms)
    const keywords = ['seo', 'free', 'best', 'tool', 'online', 'professional', 'easy'];
    const hasKeyword = keywords.some(kw => description.toLowerCase().includes(kw));
    
    // Check for call-to-action words
    const ctas = ['try', 'get', 'learn', 'discover', 'find', 'download', 'start', 'create'];
    const hasCallToAction = ctas.some(cta => description.toLowerCase().includes(cta));
    
    const suggestions: string[] = [];
    
    if (length < 120) {
      suggestions.push("Consider adding more details. Meta descriptions work best at 120-160 characters.");
    }
    if (length > 160) {
      suggestions.push("Your description might get truncated. Keep it under 160 characters.");
    }
    if (!hasKeyword) {
      suggestions.push("Include relevant keywords naturally in your description.");
    }
    if (!hasCallToAction) {
      suggestions.push("Add a call-to-action to encourage clicks (e.g., 'Try now', 'Learn more').");
    }
    if (!description.match(/[.!?]$/)) {
      suggestions.push("End with proper punctuation for a polished appearance.");
    }
    
    let score = 0;
    if (isOptimal) score += 40;
    if (hasKeyword) score += 30;
    if (hasCallToAction) score += 30;
    
    setAnalysis({ length, isOptimal, hasKeyword, hasCallToAction, score, suggestions });
  };

  return (
    <div className="space-y-4">
      <div>
        <Label htmlFor="description">Meta Description</Label>
        <Textarea
          id="description"
          placeholder="Enter your meta description here..."
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          maxLength={300}
          className="min-h-[120px]"
        />
        <div className="flex justify-between items-center mt-1">
          <p className="text-xs text-muted-foreground">
            {description.length}/160 characters
          </p>
          <p className={`text-xs font-medium ${
            description.length >= 120 && description.length <= 160 ? 'text-green-500' :
            description.length < 120 ? 'text-yellow-500' : 'text-red-500'
          }`}>
            {description.length < 120 ? 'Too short' : 
             description.length > 160 ? 'Too long' : 'Optimal length'}
          </p>
        </div>
      </div>

      <Button onClick={analyzeDescription} className="w-full" disabled={!description.trim()}>
        Analyze Meta Description
      </Button>

      {analysis && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              Score: {analysis.score}/100
            </CardTitle>
            <CardDescription>Meta description analysis results</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="w-full bg-muted rounded-full h-3">
              <div 
                className={`h-3 rounded-full transition-all ${
                  analysis.score >= 80 ? 'bg-green-500' : 
                  analysis.score >= 60 ? 'bg-yellow-500' : 'bg-red-500'
                }`}
                style={{ width: `${analysis.score}%` }}
              />
            </div>

            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm">
                {analysis.isOptimal ? (
                  <CheckCircle className="h-4 w-4 text-green-500" />
                ) : (
                  <AlertCircle className="h-4 w-4 text-yellow-500" />
                )}
                <span>Length: {analysis.length} characters</span>
              </div>

              <div className="flex items-center gap-2 text-sm">
                {analysis.hasKeyword ? (
                  <CheckCircle className="h-4 w-4 text-green-500" />
                ) : (
                  <XCircle className="h-4 w-4 text-red-500" />
                )}
                <span>Contains keywords</span>
              </div>

              <div className="flex items-center gap-2 text-sm">
                {analysis.hasCallToAction ? (
                  <CheckCircle className="h-4 w-4 text-green-500" />
                ) : (
                  <XCircle className="h-4 w-4 text-red-500" />
                )}
                <span>Includes call-to-action</span>
              </div>
            </div>

            {analysis.suggestions.length > 0 && (
              <div className="bg-muted/50 rounded-lg p-3">
                <h4 className="font-semibold text-sm mb-2">Suggestions:</h4>
                <ul className="space-y-1">
                  {analysis.suggestions.map((suggestion, index) => (
                    <li key={index} className="text-sm text-muted-foreground">
                      • {suggestion}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
