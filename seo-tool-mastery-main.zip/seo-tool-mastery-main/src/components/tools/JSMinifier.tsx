import { useState } from "react";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Copy } from "lucide-react";

export function JSMinifier() {
  const [js, setJs] = useState("");
  const [minified, setMinified] = useState("");

  const minifyJS = () => {
    if (!js.trim()) {
      toast.error("Please enter JavaScript code");
      return;
    }

    const minifiedJS = js
      .replace(/\/\*[\s\S]*?\*\//g, '')
      .replace(/\/\/.*/g, '')
      .replace(/\s+/g, ' ')
      .replace(/\s*([{};,:])\s*/g, '$1')
      .replace(/\s*=\s*/g, '=')
      .trim();

    setMinified(minifiedJS);
    const originalSize = new Blob([js]).size;
    const minifiedSize = new Blob([minifiedJS]).size;
    const savings = ((1 - minifiedSize / originalSize) * 100).toFixed(1);
    toast.success(`JavaScript minified! Size reduced by ${savings}%`);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(minified);
    toast.success("Minified JavaScript copied to clipboard!");
  };

  return (
    <div className="space-y-4">
      <div>
        <Label htmlFor="js">JavaScript Code</Label>
        <Textarea
          id="js"
          placeholder="Paste your JavaScript code here..."
          value={js}
          onChange={(e) => setJs(e.target.value)}
          className="min-h-[200px] font-mono text-sm"
        />
      </div>

      <Button onClick={minifyJS} className="w-full">
        Minify JavaScript
      </Button>

      {minified && (
        <div>
          <div className="flex justify-between items-center mb-2">
            <Label>Minified JavaScript</Label>
            <Button variant="outline" size="sm" onClick={copyToClipboard}>
              <Copy className="h-4 w-4 mr-2" />
              Copy
            </Button>
          </div>
          <Textarea
            value={minified}
            readOnly
            className="min-h-[150px] font-mono text-sm bg-muted"
          />
        </div>
      )}
    </div>
  );
}
