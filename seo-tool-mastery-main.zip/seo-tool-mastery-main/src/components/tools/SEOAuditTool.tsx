import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";
import { CheckCircle, XCircle, AlertCircle } from "lucide-react";

export function SEOAuditTool() {
  const [url, setUrl] = useState("");
  const [audit, setAudit] = useState<{
    score: number;
    checks: { name: string; status: 'pass' | 'fail' | 'warning'; message: string }[];
  } | null>(null);
  const [loading, setLoading] = useState(false);

  const runAudit = () => {
    if (!url.trim()) {
      toast.error("Please enter a URL");
      return;
    }

    setLoading(true);
    
    // Simulate SEO audit
    setTimeout(() => {
      const checks = [
        { name: "Title Tag", status: Math.random() > 0.3 ? 'pass' as const : 'fail' as const, message: "Title tag is optimized" },
        { name: "Meta Description", status: Math.random() > 0.3 ? 'pass' as const : 'warning' as const, message: "Meta description present" },
        { name: "H1 Tag", status: Math.random() > 0.2 ? 'pass' as const : 'fail' as const, message: "Single H1 tag found" },
        { name: "Image Alt Tags", status: Math.random() > 0.4 ? 'pass' as const : 'warning' as const, message: "Most images have alt text" },
        { name: "Mobile-Friendly", status: Math.random() > 0.3 ? 'pass' as const : 'fail' as const, message: "Page is mobile responsive" },
        { name: "Page Speed", status: Math.random() > 0.5 ? 'warning' as const : 'pass' as const, message: "Page loads in 2.5s" },
        { name: "SSL Certificate", status: 'pass' as const, message: "HTTPS enabled" },
        { name: "Sitemap", status: Math.random() > 0.3 ? 'pass' as const : 'fail' as const, message: "XML sitemap found" },
        { name: "Robots.txt", status: Math.random() > 0.2 ? 'pass' as const : 'fail' as const, message: "Robots.txt configured" },
        { name: "Structured Data", status: Math.random() > 0.5 ? 'warning' as const : 'pass' as const, message: "Schema markup detected" }
      ];
      
      const passed = checks.filter(c => c.status === 'pass').length;
      const score = Math.round((passed / checks.length) * 100);
      
      setAudit({ score, checks });
      setLoading(false);
      toast.success("SEO audit completed!");
    }, 2500);
  };

  const getStatusIcon = (status: 'pass' | 'fail' | 'warning') => {
    switch (status) {
      case 'pass':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'fail':
        return <XCircle className="h-4 w-4 text-red-500" />;
      case 'warning':
        return <AlertCircle className="h-4 w-4 text-yellow-500" />;
    }
  };

  return (
    <div className="space-y-4">
      <div>
        <Label htmlFor="url">Website URL</Label>
        <Input
          id="url"
          placeholder="https://yourwebsite.com"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
        />
      </div>

      <Button onClick={runAudit} className="w-full" disabled={loading}>
        {loading ? "Running Audit..." : "Run SEO Audit"}
      </Button>

      {audit && (
        <Card>
          <CardHeader>
            <CardTitle>SEO Audit Results</CardTitle>
            <CardDescription>{url}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-center p-6 border rounded-lg bg-muted/50">
              <div className={`text-5xl font-bold ${
                audit.score >= 80 ? 'text-green-500' :
                audit.score >= 60 ? 'text-yellow-500' : 'text-red-500'
              }`}>
                {audit.score}
              </div>
              <div className="text-sm text-muted-foreground mt-2">SEO Score</div>
            </div>
            
            <div className="space-y-2">
              {audit.checks.map((check, index) => (
                <div key={index} className="flex items-start gap-3 p-3 border rounded">
                  {getStatusIcon(check.status)}
                  <div className="flex-1">
                    <div className="font-medium text-sm">{check.name}</div>
                    <div className="text-xs text-muted-foreground">{check.message}</div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
