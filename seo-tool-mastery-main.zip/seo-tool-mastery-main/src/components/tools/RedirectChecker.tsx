import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";
import { ArrowRight } from "lucide-react";

export function RedirectChecker() {
  const [url, setUrl] = useState("");
  const [redirects, setRedirects] = useState<{
    chain: { url: string; status: number }[];
    final: string;
  } | null>(null);
  const [loading, setLoading] = useState(false);

  const checkRedirects = () => {
    if (!url.trim()) {
      toast.error("Please enter a URL");
      return;
    }

    setLoading(true);
    
    // Simulate redirect checking
    setTimeout(() => {
      const redirectCount = Math.floor(Math.random() * 3);
      const chain: { url: string; status: number }[] = [
        { url: url, status: redirectCount > 0 ? 301 : 200 }
      ];
      
      if (redirectCount > 0) {
        chain.push({ url: `${url}/redirect-1`, status: redirectCount > 1 ? 302 : 200 });
      }
      
      if (redirectCount > 1) {
        chain.push({ url: `${url}/final`, status: 200 });
      }
      
      const final = chain[chain.length - 1].url;
      
      setRedirects({ chain, final });
      setLoading(false);
      
      if (redirectCount === 0) {
        toast.success("No redirects found");
      } else {
        toast.warning(`Found ${redirectCount} redirect${redirectCount > 1 ? 's' : ''}`);
      }
    }, 1500);
  };

  const getStatusColor = (status: number) => {
    if (status === 200) return "text-green-500";
    if (status === 301 || status === 302) return "text-yellow-500";
    return "text-red-500";
  };

  const getStatusLabel = (status: number) => {
    switch (status) {
      case 200: return "OK";
      case 301: return "Permanent Redirect";
      case 302: return "Temporary Redirect";
      default: return "Error";
    }
  };

  return (
    <div className="space-y-4">
      <div>
        <Label htmlFor="url">URL to Check</Label>
        <Input
          id="url"
          placeholder="https://yourwebsite.com/old-page"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
        />
      </div>

      <Button onClick={checkRedirects} className="w-full" disabled={loading}>
        {loading ? "Checking..." : "Check Redirects"}
      </Button>

      {redirects && (
        <Card>
          <CardHeader>
            <CardTitle>Redirect Chain</CardTitle>
            <CardDescription>
              {redirects.chain.length - 1 === 0 ? 
                "No redirects detected" : 
                `${redirects.chain.length - 1} redirect${redirects.chain.length > 2 ? 's' : ''} found`
              }
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {redirects.chain.map((step, index) => (
                <div key={index}>
                  <div className="border rounded-lg p-3">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1">
                        <div className="text-xs text-muted-foreground mb-1">
                          Step {index + 1}
                        </div>
                        <div className="text-sm font-medium break-all">{step.url}</div>
                      </div>
                      <div className="flex flex-col items-end gap-1">
                        <span className={`text-xs font-semibold ${getStatusColor(step.status)}`}>
                          {step.status}
                        </span>
                        <span className="text-xs text-muted-foreground">
                          {getStatusLabel(step.status)}
                        </span>
                      </div>
                    </div>
                  </div>
                  
                  {index < redirects.chain.length - 1 && (
                    <div className="flex justify-center my-2">
                      <ArrowRight className="h-4 w-4 text-muted-foreground" />
                    </div>
                  )}
                </div>
              ))}
            </div>

            {redirects.chain.length > 2 && (
              <div className="mt-4 p-3 bg-yellow-50 dark:bg-yellow-950/20 border border-yellow-200 dark:border-yellow-900 rounded-lg">
                <p className="text-sm text-yellow-800 dark:text-yellow-200">
                  ⚠️ Multiple redirects detected. Consider reducing redirect chains for better SEO.
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
