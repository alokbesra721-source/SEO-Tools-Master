import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";
import { AlertCircle, CheckCircle } from "lucide-react";

export function BrokenLinkChecker() {
  const [url, setUrl] = useState("");
  const [results, setResults] = useState<{
    total: number;
    working: number;
    broken: number;
    brokenLinks: { url: string; status: number }[];
  } | null>(null);
  const [loading, setLoading] = useState(false);

  const checkLinks = () => {
    if (!url.trim()) {
      toast.error("Please enter a website URL");
      return;
    }

    setLoading(true);
    
    // Simulate broken link checking
    setTimeout(() => {
      const total = Math.floor(Math.random() * 30) + 20;
      const broken = Math.floor(Math.random() * 5);
      const working = total - broken;
      
      const brokenLinks = Array.from({ length: broken }, (_, i) => ({
        url: `${url}/page-${i + 1}`,
        status: [404, 500, 503][Math.floor(Math.random() * 3)]
      }));
      
      setResults({ total, working, broken, brokenLinks });
      setLoading(false);
      
      if (broken === 0) {
        toast.success("No broken links found!");
      } else {
        toast.warning(`Found ${broken} broken links`);
      }
    }, 2000);
  };

  return (
    <div className="space-y-4">
      <div>
        <Label htmlFor="url">Website URL</Label>
        <Input
          id="url"
          placeholder="https://yourwebsite.com"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
        />
      </div>

      <Button onClick={checkLinks} className="w-full" disabled={loading}>
        {loading ? "Scanning Links..." : "Check Broken Links"}
      </Button>

      {results && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              {results.broken === 0 ? (
                <CheckCircle className="h-5 w-5 text-green-500" />
              ) : (
                <AlertCircle className="h-5 w-5 text-red-500" />
              )}
              Link Check Results
            </CardTitle>
            <CardDescription>{url}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-3 gap-4">
              <div className="text-center p-3 border rounded">
                <div className="text-2xl font-bold text-primary">{results.total}</div>
                <div className="text-xs text-muted-foreground mt-1">Total Links</div>
              </div>
              
              <div className="text-center p-3 border rounded">
                <div className="text-2xl font-bold text-green-500">{results.working}</div>
                <div className="text-xs text-muted-foreground mt-1">Working</div>
              </div>
              
              <div className="text-center p-3 border rounded">
                <div className="text-2xl font-bold text-red-500">{results.broken}</div>
                <div className="text-xs text-muted-foreground mt-1">Broken</div>
              </div>
            </div>

            {results.brokenLinks.length > 0 && (
              <div className="bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-900 rounded-lg p-3">
                <h4 className="font-semibold text-sm text-red-900 dark:text-red-200 mb-2">
                  Broken Links Found:
                </h4>
                <div className="space-y-2">
                  {results.brokenLinks.map((link, index) => (
                    <div key={index} className="text-sm flex justify-between items-center">
                      <span className="text-red-800 dark:text-red-300 break-all flex-1">{link.url}</span>
                      <span className="ml-2 px-2 py-1 bg-red-200 dark:bg-red-900 text-red-900 dark:text-red-200 rounded text-xs font-medium">
                        {link.status}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
