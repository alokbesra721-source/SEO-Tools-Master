import { useState } from "react";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";
import { CheckCircle, XCircle } from "lucide-react";

export function XMLSitemapValidator() {
  const [xml, setXml] = useState("");
  const [validation, setValidation] = useState<{
    isValid: boolean;
    urls: number;
    errors: string[];
  } | null>(null);

  const validateSitemap = () => {
    if (!xml.trim()) {
      toast.error("Please enter XML sitemap content");
      return;
    }

    const errors: string[] = [];
    let urls = 0;
    
    // Basic XML validation
    if (!xml.includes('<?xml')) {
      errors.push("Missing XML declaration");
    }
    
    if (!xml.includes('<urlset')) {
      errors.push("Missing <urlset> tag");
    }
    
    if (!xml.includes('xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"')) {
      errors.push("Missing or incorrect xmlns attribute");
    }
    
    // Count URLs
    const urlMatches = xml.match(/<url>/g);
    urls = urlMatches ? urlMatches.length : 0;
    
    if (urls === 0) {
      errors.push("No URLs found in sitemap");
    }
    
    // Check for required loc tags
    const locMatches = xml.match(/<loc>/g);
    const locCount = locMatches ? locMatches.length : 0;
    
    if (locCount < urls) {
      errors.push("Some URLs are missing <loc> tags");
    }
    
    const isValid = errors.length === 0;
    setValidation({ isValid, urls, errors });
    
    if (isValid) {
      toast.success("Sitemap is valid!");
    } else {
      toast.error("Validation errors found");
    }
  };

  return (
    <div className="space-y-4">
      <div>
        <Label htmlFor="xml">XML Sitemap Content</Label>
        <Textarea
          id="xml"
          placeholder='<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>https://example.com/</loc>
    <lastmod>2025-01-01</lastmod>
    <priority>1.0</priority>
  </url>
</urlset>'
          value={xml}
          onChange={(e) => setXml(e.target.value)}
          className="min-h-[250px] font-mono text-sm"
        />
      </div>

      <Button onClick={validateSitemap} className="w-full">
        Validate Sitemap
      </Button>

      {validation && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              {validation.isValid ? (
                <>
                  <CheckCircle className="h-5 w-5 text-green-500" />
                  Valid Sitemap
                </>
              ) : (
                <>
                  <XCircle className="h-5 w-5 text-red-500" />
                  Invalid Sitemap
                </>
              )}
            </CardTitle>
            <CardDescription>
              {validation.urls} URL{validation.urls !== 1 ? 's' : ''} found
            </CardDescription>
          </CardHeader>
          <CardContent>
            {validation.isValid ? (
              <div className="bg-green-50 dark:bg-green-950/20 border border-green-200 dark:border-green-900 rounded-lg p-4">
                <p className="text-sm text-green-800 dark:text-green-200">
                  ✓ Your sitemap is properly formatted and ready to submit to search engines.
                </p>
              </div>
            ) : (
              <div className="bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-900 rounded-lg p-4">
                <h4 className="font-semibold text-sm text-red-900 dark:text-red-200 mb-2">
                  Errors Found:
                </h4>
                <ul className="space-y-1">
                  {validation.errors.map((error, index) => (
                    <li key={index} className="text-sm text-red-800 dark:text-red-300">
                      • {error}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
