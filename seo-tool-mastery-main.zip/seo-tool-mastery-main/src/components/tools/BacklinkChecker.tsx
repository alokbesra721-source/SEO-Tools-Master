import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";
import { ExternalLink } from "lucide-react";

export function BacklinkChecker() {
  const [url, setUrl] = useState("");
  const [backlinks, setBacklinks] = useState<{ url: string; da: number; anchor: string }[]>([]);
  const [loading, setLoading] = useState(false);

  const checkBacklinks = async () => {
    if (!url.trim()) {
      toast.error("Please enter a URL");
      return;
    }

    setLoading(true);
    
    // Simulate backlink checking
    setTimeout(() => {
      const mockBacklinks = [
        { url: "https://example.com/blog/seo-tips", da: 65, anchor: "SEO Tools" },
        { url: "https://techblog.net/best-tools", da: 58, anchor: "Free SEO Tools" },
        { url: "https://marketing.io/resources", da: 72, anchor: url },
        { url: "https://webdev.com/tools-list", da: 45, anchor: "SEO Master" },
        { url: "https://digitalmarketing.org/guides", da: 81, anchor: "Click here" }
      ];
      
      setBacklinks(mockBacklinks);
      setLoading(false);
      toast.success(`Found ${mockBacklinks.length} backlinks!`);
    }, 1500);
  };

  return (
    <div className="space-y-4">
      <div>
        <Label htmlFor="url">Website URL</Label>
        <Input
          id="url"
          placeholder="https://yourwebsite.com"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
        />
      </div>

      <Button onClick={checkBacklinks} className="w-full" disabled={loading}>
        {loading ? "Analyzing..." : "Check Backlinks"}
      </Button>

      {backlinks.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Backlinks Found: {backlinks.length}</CardTitle>
            <CardDescription>Websites linking to your domain</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {backlinks.map((link, index) => (
                <div key={index} className="border rounded-lg p-3">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1">
                      <a 
                        href={link.url} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-sm font-medium text-primary hover:underline flex items-center gap-1"
                      >
                        {link.url}
                        <ExternalLink className="h-3 w-3" />
                      </a>
                      <p className="text-xs text-muted-foreground mt-1">
                        Anchor: "{link.anchor}"
                      </p>
                    </div>
                    <span className="text-xs font-semibold bg-primary/10 text-primary px-2 py-1 rounded">
                      DA: {link.da}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
