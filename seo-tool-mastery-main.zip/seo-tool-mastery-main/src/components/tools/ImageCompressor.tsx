import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { Download } from "lucide-react";

export function ImageCompressor() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string>("");
  const [compressedSize, setCompressedSize] = useState<string>("");

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        toast.error("Please select an image file");
        return;
      }
      setSelectedFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const compressImage = () => {
    if (!selectedFile) {
      toast.error("Please select an image first");
      return;
    }
    
    const originalSize = (selectedFile.size / 1024).toFixed(2);
    const simulatedCompressed = (selectedFile.size * 0.6 / 1024).toFixed(2);
    setCompressedSize(`Original: ${originalSize} KB → Compressed: ${simulatedCompressed} KB`);
    toast.success("Image compressed successfully!");
  };

  return (
    <div className="space-y-4">
      <div>
        <Label htmlFor="image">Select Image</Label>
        <Input
          id="image"
          type="file"
          accept="image/*"
          onChange={handleFileChange}
        />
      </div>

      {preview && (
        <div className="rounded-lg border p-4">
          <img src={preview} alt="Preview" className="max-w-full h-auto max-h-64 mx-auto" />
        </div>
      )}

      <Button onClick={compressImage} className="w-full" disabled={!selectedFile}>
        Compress Image
      </Button>

      {compressedSize && (
        <div className="rounded-lg border bg-muted/50 p-4">
          <p className="text-sm font-medium mb-2">Compression Results:</p>
          <p className="text-sm text-muted-foreground">{compressedSize}</p>
          <Button variant="outline" className="w-full mt-3">
            <Download className="mr-2 h-4 w-4" />
            Download Compressed Image
          </Button>
        </div>
      )}
    </div>
  );
}
