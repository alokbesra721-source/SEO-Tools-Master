import { useState } from "react";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Copy } from "lucide-react";

export function CSSMinifier() {
  const [css, setCss] = useState("");
  const [minified, setMinified] = useState("");

  const minifyCSS = () => {
    if (!css.trim()) {
      toast.error("Please enter CSS code");
      return;
    }

    const minifiedCSS = css
      .replace(/\/\*[\s\S]*?\*\//g, '')
      .replace(/\s+/g, ' ')
      .replace(/\s*{\s*/g, '{')
      .replace(/\s*}\s*/g, '}')
      .replace(/\s*;\s*/g, ';')
      .replace(/\s*:\s*/g, ':')
      .replace(/\s*,\s*/g, ',')
      .trim();

    setMinified(minifiedCSS);
    const originalSize = new Blob([css]).size;
    const minifiedSize = new Blob([minifiedCSS]).size;
    const savings = ((1 - minifiedSize / originalSize) * 100).toFixed(1);
    toast.success(`CSS minified! Size reduced by ${savings}%`);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(minified);
    toast.success("Minified CSS copied to clipboard!");
  };

  return (
    <div className="space-y-4">
      <div>
        <Label htmlFor="css">CSS Code</Label>
        <Textarea
          id="css"
          placeholder="Paste your CSS code here..."
          value={css}
          onChange={(e) => setCss(e.target.value)}
          className="min-h-[200px] font-mono text-sm"
        />
      </div>

      <Button onClick={minifyCSS} className="w-full">
        Minify CSS
      </Button>

      {minified && (
        <div>
          <div className="flex justify-between items-center mb-2">
            <Label>Minified CSS</Label>
            <Button variant="outline" size="sm" onClick={copyToClipboard}>
              <Copy className="h-4 w-4 mr-2" />
              Copy
            </Button>
          </div>
          <Textarea
            value={minified}
            readOnly
            className="min-h-[150px] font-mono text-sm bg-muted"
          />
        </div>
      )}
    </div>
  );
}
