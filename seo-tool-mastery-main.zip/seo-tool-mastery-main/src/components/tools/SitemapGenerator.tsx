import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { Copy, Download } from "lucide-react";

export function SitemapGenerator() {
  const [domain, setDomain] = useState("");
  const [pages, setPages] = useState("");
  const [sitemap, setSitemap] = useState("");

  const generateSitemap = () => {
    if (!domain.trim()) {
      toast.error("Please enter your domain");
      return;
    }

    const pageList = pages.split('\n').filter(p => p.trim());
    const baseUrl = domain.trim().replace(/\/$/, '');
    
    let xml = '<?xml version="1.0" encoding="UTF-8"?>\n';
    xml += '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n';
    
    // Add homepage
    xml += '  <url>\n';
    xml += `    <loc>${baseUrl}/</loc>\n`;
    xml += `    <lastmod>${new Date().toISOString().split('T')[0]}</lastmod>\n`;
    xml += '    <priority>1.0</priority>\n';
    xml += '  </url>\n';
    
    // Add custom pages
    pageList.forEach(page => {
      const cleanPage = page.trim().replace(/^\//, '');
      xml += '  <url>\n';
      xml += `    <loc>${baseUrl}/${cleanPage}</loc>\n`;
      xml += `    <lastmod>${new Date().toISOString().split('T')[0]}</lastmod>\n`;
      xml += '    <priority>0.8</priority>\n';
      xml += '  </url>\n';
    });
    
    xml += '</urlset>';
    
    setSitemap(xml);
    toast.success("Sitemap generated successfully!");
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(sitemap);
    toast.success("Sitemap copied to clipboard!");
  };

  const downloadSitemap = () => {
    const blob = new Blob([sitemap], { type: 'text/xml' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'sitemap.xml';
    a.click();
    URL.revokeObjectURL(url);
    toast.success("Sitemap downloaded!");
  };

  return (
    <div className="space-y-4">
      <div>
        <Label htmlFor="domain">Website Domain</Label>
        <Input
          id="domain"
          placeholder="https://yourwebsite.com"
          value={domain}
          onChange={(e) => setDomain(e.target.value)}
        />
      </div>

      <div>
        <Label htmlFor="pages">Pages (one per line)</Label>
        <Textarea
          id="pages"
          placeholder="about&#10;services&#10;contact&#10;blog&#10;products"
          value={pages}
          onChange={(e) => setPages(e.target.value)}
          className="min-h-[120px] font-mono text-sm"
        />
        <p className="text-xs text-muted-foreground mt-1">
          Enter one page path per line (without domain)
        </p>
      </div>

      <Button onClick={generateSitemap} className="w-full">
        Generate Sitemap
      </Button>

      {sitemap && (
        <div>
          <div className="flex justify-between items-center mb-2">
            <Label>Generated Sitemap (sitemap.xml)</Label>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={copyToClipboard}>
                <Copy className="h-4 w-4 mr-2" />
                Copy
              </Button>
              <Button variant="outline" size="sm" onClick={downloadSitemap}>
                <Download className="h-4 w-4 mr-2" />
                Download
              </Button>
            </div>
          </div>
          <Textarea
            value={sitemap}
            readOnly
            className="min-h-[250px] font-mono text-xs bg-muted"
          />
        </div>
      )}
    </div>
  );
}
