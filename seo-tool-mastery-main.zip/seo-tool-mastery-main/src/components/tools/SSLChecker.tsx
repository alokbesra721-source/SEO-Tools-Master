import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";
import { CheckCircle, XCircle, Shield } from "lucide-react";

export function SSLChecker() {
  const [url, setUrl] = useState("");
  const [sslInfo, setSslInfo] = useState<{
    isValid: boolean;
    issuer: string;
    validFrom: string;
    validTo: string;
    daysRemaining: number;
    protocol: string;
  } | null>(null);
  const [loading, setLoading] = useState(false);

  const checkSSL = () => {
    if (!url.trim()) {
      toast.error("Please enter a domain");
      return;
    }

    setLoading(true);
    
    // Simulate SSL checking
    setTimeout(() => {
      const isValid = Math.random() > 0.2;
      const daysRemaining = Math.floor(Math.random() * 365) + 1;
      const validFrom = new Date(Date.now() - 365 * 24 * 60 * 60 * 1000);
      const validTo = new Date(Date.now() + daysRemaining * 24 * 60 * 60 * 1000);
      
      const issuers = [
        "Let's Encrypt Authority X3",
        "DigiCert SHA2 Secure Server CA",
        "Amazon RSA 2048 M01",
        "Cloudflare Inc ECC CA-3"
      ];
      
      setSslInfo({
        isValid,
        issuer: issuers[Math.floor(Math.random() * issuers.length)],
        validFrom: validFrom.toLocaleDateString(),
        validTo: validTo.toLocaleDateString(),
        daysRemaining,
        protocol: "TLS 1.3"
      });
      
      setLoading(false);
      
      if (isValid) {
        toast.success("SSL certificate is valid!");
      } else {
        toast.error("SSL certificate issues detected");
      }
    }, 1500);
  };

  return (
    <div className="space-y-4">
      <div>
        <Label htmlFor="domain">Domain Name</Label>
        <Input
          id="domain"
          placeholder="example.com"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
        />
      </div>

      <Button onClick={checkSSL} className="w-full" disabled={loading}>
        {loading ? "Checking SSL..." : "Check SSL Certificate"}
      </Button>

      {sslInfo && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              {sslInfo.isValid ? (
                <>
                  <Shield className="h-5 w-5 text-green-500" />
                  SSL Certificate Valid
                </>
              ) : (
                <>
                  <XCircle className="h-5 w-5 text-red-500" />
                  SSL Certificate Issues
                </>
              )}
            </CardTitle>
            <CardDescription>{url}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-3">
              <div className="flex justify-between items-center p-3 border rounded">
                <span className="text-sm text-muted-foreground">Issuer</span>
                <span className="text-sm font-medium">{sslInfo.issuer}</span>
              </div>
              
              <div className="flex justify-between items-center p-3 border rounded">
                <span className="text-sm text-muted-foreground">Protocol</span>
                <span className="text-sm font-medium">{sslInfo.protocol}</span>
              </div>
              
              <div className="flex justify-between items-center p-3 border rounded">
                <span className="text-sm text-muted-foreground">Valid From</span>
                <span className="text-sm font-medium">{sslInfo.validFrom}</span>
              </div>
              
              <div className="flex justify-between items-center p-3 border rounded">
                <span className="text-sm text-muted-foreground">Valid To</span>
                <span className="text-sm font-medium">{sslInfo.validTo}</span>
              </div>
              
              <div className="flex justify-between items-center p-3 border rounded">
                <span className="text-sm text-muted-foreground">Days Remaining</span>
                <span className={`text-sm font-medium ${
                  sslInfo.daysRemaining > 30 ? 'text-green-500' : 
                  sslInfo.daysRemaining > 7 ? 'text-yellow-500' : 'text-red-500'
                }`}>
                  {sslInfo.daysRemaining} days
                </span>
              </div>
            </div>

            {sslInfo.daysRemaining < 30 && (
              <div className={`p-3 rounded-lg border ${
                sslInfo.daysRemaining < 7 ? 
                'bg-red-50 dark:bg-red-950/20 border-red-200 dark:border-red-900' :
                'bg-yellow-50 dark:bg-yellow-950/20 border-yellow-200 dark:border-yellow-900'
              }`}>
                <p className={`text-sm ${
                  sslInfo.daysRemaining < 7 ?
                  'text-red-800 dark:text-red-200' :
                  'text-yellow-800 dark:text-yellow-200'
                }`}>
                  {sslInfo.daysRemaining < 7 ? '⚠️' : '⚡'} Your SSL certificate will expire soon. Consider renewing it.
                </p>
              </div>
            )}

            {sslInfo.isValid && sslInfo.daysRemaining > 30 && (
              <div className="flex items-center gap-2 p-3 bg-green-50 dark:bg-green-950/20 border border-green-200 dark:border-green-900 rounded-lg">
                <CheckCircle className="h-4 w-4 text-green-500 flex-shrink-0" />
                <p className="text-sm text-green-800 dark:text-green-200">
                  Your website is secure with a valid SSL certificate.
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
