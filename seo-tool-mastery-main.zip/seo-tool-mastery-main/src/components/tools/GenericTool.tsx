import { Tool } from "@/data/tools";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { useState } from "react";
import { toast } from "sonner";

interface GenericToolProps {
  tool: Tool;
}

export function GenericTool({ tool }: GenericToolProps) {
  const [input, setInput] = useState("");
  const [result, setResult] = useState("");

  const handleAnalyze = () => {
    if (!input.trim()) {
      toast.error("Please enter a value to analyze");
      return;
    }
    
    setResult(`Analysis complete for ${tool.name}. This is a demo result.`);
    toast.success("Analysis complete!");
  };

  return (
    <div className="space-y-4">
      <div>
        <Label htmlFor="input">Enter URL or Text</Label>
        <Input
          id="input"
          placeholder={`Enter value for ${tool.name}...`}
          value={input}
          onChange={(e) => setInput(e.target.value)}
        />
      </div>

      <Button onClick={handleAnalyze} className="w-full">
        Analyze
      </Button>

      {result && (
        <div className="rounded-lg border bg-muted/50 p-4">
          <p className="text-sm">{result}</p>
        </div>
      )}

      <div className="rounded-lg border bg-muted/50 p-4">
        <h4 className="font-semibold mb-2">About this tool:</h4>
        <p className="text-sm text-muted-foreground">{tool.description}</p>
      </div>
    </div>
  );
}
