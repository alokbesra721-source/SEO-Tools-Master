import { useState } from "react";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Copy } from "lucide-react";

export function HTMLFormatter() {
  const [html, setHtml] = useState("");
  const [formatted, setFormatted] = useState("");

  const formatHTML = () => {
    if (!html.trim()) {
      toast.error("Please enter HTML code");
      return;
    }

    // Basic HTML formatting
    let result = html
      .replace(/></g, '>\n<')
      .replace(/\n\s*\n/g, '\n');
    
    const lines = result.split('\n');
    let indentLevel = 0;
    const indentSize = 2;
    
    const formattedLines = lines.map(line => {
      const trimmedLine = line.trim();
      if (!trimmedLine) return '';
      
      // Decrease indent for closing tags
      if (trimmedLine.startsWith('</')) {
        indentLevel = Math.max(0, indentLevel - 1);
      }
      
      const indentedLine = ' '.repeat(indentLevel * indentSize) + trimmedLine;
      
      // Increase indent for opening tags
      if (trimmedLine.startsWith('<') && 
          !trimmedLine.startsWith('</') && 
          !trimmedLine.endsWith('/>') &&
          !trimmedLine.startsWith('<!')) {
        indentLevel++;
      }
      
      return indentedLine;
    });
    
    const formattedHTML = formattedLines.filter(line => line).join('\n');
    setFormatted(formattedHTML);
    toast.success("HTML formatted successfully!");
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(formatted);
    toast.success("Formatted HTML copied to clipboard!");
  };

  return (
    <div className="space-y-4">
      <div>
        <Label htmlFor="html">HTML Code</Label>
        <Textarea
          id="html"
          placeholder="Paste your HTML code here..."
          value={html}
          onChange={(e) => setHtml(e.target.value)}
          className="min-h-[200px] font-mono text-sm"
        />
      </div>

      <Button onClick={formatHTML} className="w-full">
        Format HTML
      </Button>

      {formatted && (
        <div>
          <div className="flex justify-between items-center mb-2">
            <Label>Formatted HTML</Label>
            <Button variant="outline" size="sm" onClick={copyToClipboard}>
              <Copy className="h-4 w-4 mr-2" />
              Copy
            </Button>
          </div>
          <Textarea
            value={formatted}
            readOnly
            className="min-h-[200px] font-mono text-sm bg-muted"
          />
        </div>
      )}
    </div>
  );
}
