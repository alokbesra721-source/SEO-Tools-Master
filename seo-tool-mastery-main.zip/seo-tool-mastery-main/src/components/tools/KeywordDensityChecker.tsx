import { useState } from "react";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export function KeywordDensityChecker() {
  const [text, setText] = useState("");
  const [results, setResults] = useState<{ word: string; count: number; density: string }[]>([]);

  const analyzeText = () => {
    const words = text.toLowerCase().match(/\b[a-z]+\b/g) || [];
    const totalWords = words.length;
    const wordCount: { [key: string]: number } = {};

    words.forEach(word => {
      if (word.length > 3) {
        wordCount[word] = (wordCount[word] || 0) + 1;
      }
    });

    const sortedResults = Object.entries(wordCount)
      .map(([word, count]) => ({
        word,
        count,
        density: ((count / totalWords) * 100).toFixed(2)
      }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 20);

    setResults(sortedResults);
  };

  return (
    <div className="space-y-4">
      <Textarea
        placeholder="Paste your content here..."
        value={text}
        onChange={(e) => setText(e.target.value)}
        className="min-h-[200px]"
      />
      <Button onClick={analyzeText} className="w-full">Analyze Keyword Density</Button>
      
      {results.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Results</CardTitle>
            <CardDescription>Top keywords by frequency</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {results.map((result, index) => (
                <div key={index} className="flex justify-between border-b pb-2">
                  <span className="font-medium">{result.word}</span>
                  <span className="text-muted-foreground">
                    {result.count} times ({result.density}%)
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
