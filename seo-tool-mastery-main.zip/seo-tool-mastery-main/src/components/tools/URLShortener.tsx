import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Copy, ExternalLink } from "lucide-react";

export function URLShortener() {
  const [longUrl, setLongUrl] = useState("");
  const [shortUrl, setShortUrl] = useState("");
  const [customAlias, setCustomAlias] = useState("");

  const shortenURL = () => {
    if (!longUrl.trim()) {
      toast.error("Please enter a URL to shorten");
      return;
    }

    try {
      new URL(longUrl);
    } catch {
      toast.error("Please enter a valid URL");
      return;
    }

    const alias = customAlias.trim() || Math.random().toString(36).substring(2, 8);
    const shortened = `https://short.link/${alias}`;
    
    setShortUrl(shortened);
    toast.success("URL shortened successfully!");
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(shortUrl);
    toast.success("Short URL copied to clipboard!");
  };

  return (
    <div className="space-y-4">
      <div>
        <Label htmlFor="longUrl">Long URL</Label>
        <Input
          id="longUrl"
          placeholder="https://yourverylongwebsiteurl.com/page/subpage/article"
          value={longUrl}
          onChange={(e) => setLongUrl(e.target.value)}
        />
      </div>

      <div>
        <Label htmlFor="customAlias">Custom Alias (optional)</Label>
        <Input
          id="customAlias"
          placeholder="my-custom-link"
          value={customAlias}
          onChange={(e) => setCustomAlias(e.target.value)}
        />
        <p className="text-xs text-muted-foreground mt-1">
          Leave empty for random short URL
        </p>
      </div>

      <Button onClick={shortenURL} className="w-full">
        Shorten URL
      </Button>

      {shortUrl && (
        <div className="rounded-lg border bg-muted/50 p-4 space-y-3">
          <div>
            <Label className="text-xs text-muted-foreground">Original URL:</Label>
            <p className="text-sm break-all">{longUrl}</p>
          </div>
          
          <div>
            <Label className="text-xs text-muted-foreground">Short URL:</Label>
            <div className="flex items-center gap-2 mt-1">
              <a 
                href={shortUrl} 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-lg font-medium text-primary hover:underline flex items-center gap-1"
              >
                {shortUrl}
                <ExternalLink className="h-4 w-4" />
              </a>
            </div>
          </div>

          <Button variant="outline" className="w-full" onClick={copyToClipboard}>
            <Copy className="mr-2 h-4 w-4" />
            Copy Short URL
          </Button>
        </div>
      )}
    </div>
  );
}
